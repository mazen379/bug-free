#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "SDL/SDL_ttf.h"
#include"score.h"
#define WIDTH 1400
#define HEIGHT 600


int main ( int argc, char* argv[])
{
        SDL_Surface *ecran = NULL;
        SDL_Event event;
        int gameover = 1;
        int test;
	score s;
        SDL_Color color={0,0,0};
        s.val=0;
        SDL_Init(SDL_INIT_VIDEO);
        ecran = SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
        TTF_Init();
        setup(&s,ecran);
        //SDL_EnableKeyRepeat(10,10);
        while(gameover)
        {
	  SDL_Event event ;
          SDL_WaitEvent(&event);
         switch(event.type)
        {
                       
                        case SDL_QUIT:
                                gameover = 0;
                                break;
                        case SDL_KEYDOWN:
                                 setup(&s,ecran);
                                 break;                              
          }
        }
	freescore(&s);
        TTF_Quit();
        SDL_Quit();
        return 0;
}
