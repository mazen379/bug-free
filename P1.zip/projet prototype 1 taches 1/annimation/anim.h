#ifndef ENIGME_H_INCLUDED
#define ENIGME_H_INCLUDED

int anim(int argc, char *argv[]);

#endif // ENIGME_H_INCLUDED
