#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include"vie.h"
#define WIDTH 1400
#define HEIGHT 600


int main ( int argc, char* argv[] )
{
        SDL_Surface *ecran = NULL;
        
        SDL_Event event;
        int gameover = 1;
        int test;
	vie v;
        SDL_Init(SDL_INIT_VIDEO);
        ecran = SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
        init_vie(&v);
        //SDL_EnableKeyRepeat(10,10);
        v.val=5;
        setup( v ,ecran);
        while(gameover)
        {
	  SDL_Event event ;

 SDL_WaitEvent(&event);
     switch(event.type)
        {
                       
                        case SDL_QUIT:
                                gameover = 0;
                                break;
                        case SDL_KEYDOWN:
                                if(v.val!=0)
				 v.val--;
                                 displayvie(v ,ecran); 
                                 break;
                              
          }
        }
	vie_freevie(&v);
        SDL_Quit();
        return 0;
}
